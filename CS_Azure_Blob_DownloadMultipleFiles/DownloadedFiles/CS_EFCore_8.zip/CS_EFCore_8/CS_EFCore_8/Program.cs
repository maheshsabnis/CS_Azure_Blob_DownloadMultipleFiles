﻿// See https://aka.ms/new-console-template for more information
using CS_EFCore_8.Models;

Console.WriteLine("EF Core 8 New Features");
EFCore8FeatureContext context = new EFCore8FeatureContext();
Console.ReadLine();
